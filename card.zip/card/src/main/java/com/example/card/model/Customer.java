package com.example.card.model;

public class Customer {
	private int customerId;
	public int getcustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

}
